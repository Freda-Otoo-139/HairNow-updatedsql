<?php

// set up constants for database connection
// database, user, password, server

define('SERVER', 'localhost');
define('USER', 'root');
define('DATABASE', 'shoppn');
define('PASSWORD', '');

?>